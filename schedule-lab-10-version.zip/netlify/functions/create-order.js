const Razorpay = require('razorpay');

exports.handler = async function (event) {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  // Auth failure check: credentials missing from environment
  const keyId = process.env.RAZORPAY_KEY_ID;
  const keySecret = process.env.RAZORPAY_KEY_SECRET;
  if (!keyId || !keySecret) {
    return { statusCode: 401, body: JSON.stringify({ error: 'Razorpay credentials not configured on server' }) };
  }

  let body;
  try {
    body = JSON.parse(event.body || '{}');
  } catch (e) {
    return { statusCode: 400, body: JSON.stringify({ error: 'Invalid JSON body' }) };
  }

  const { amount, currency, receipt } = body;

  // Validate amount >= 100 paise (₹1 minimum per Razorpay rules)
  if (!amount || typeof amount !== 'number' || amount < 100) {
    return { statusCode: 400, body: JSON.stringify({ error: 'Amount must be at least 100 paise (₹1)' }) };
  }

  const razorpay = new Razorpay({ key_id: keyId, key_secret: keySecret });

  try {
    const order = await razorpay.orders.create({
      amount: Math.round(amount),
      currency: currency || 'INR',
      receipt: receipt || `receipt_${Date.now()}`
    });

    return {
      statusCode: 200,
      body: JSON.stringify({
        order_id: order.id,
        amount: order.amount,
        currency: order.currency
      })
    };
  } catch (err) {
    console.error('Razorpay create order error:', err);
    return { statusCode: 500, body: JSON.stringify({ error: 'Failed to create order' }) };
  }
};
